declare const locale: {
    lang: any;
    timePickerLocale: any;
};
export default locale;
