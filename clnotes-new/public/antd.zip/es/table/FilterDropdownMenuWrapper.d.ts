/// <reference types="react" />
import React from 'react';
export interface FilterDropdownMenuWrapperProps {
    onClick?: React.MouseEventHandler<any>;
    children?: any;
    className?: string;
}
declare const _default: (props: FilterDropdownMenuWrapperProps) => JSX.Element;
export default _default;
