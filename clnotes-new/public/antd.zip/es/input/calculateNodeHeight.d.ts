export default function calculateNodeHeight(uiTextNode: any, useCache?: boolean, minRows?: number | null, maxRows?: number | null): {
    height: any;
    minHeight: number;
    maxHeight: number;
    overflowY: any;
};
