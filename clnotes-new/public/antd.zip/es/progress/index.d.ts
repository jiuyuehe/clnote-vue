import Progress from './progress';
export default Progress;
