import Modal, { ModalFuncProps } from './Modal';
export { ModalFuncProps };
export default Modal;
