declare const animation: {
    enter(node: any, done: any): any;
    leave(node: any, done: any): any;
    appear(node: any, done: any): any;
};
export default animation;
