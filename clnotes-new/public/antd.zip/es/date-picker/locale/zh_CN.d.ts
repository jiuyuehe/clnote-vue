import 'moment/locale/zh-cn';
declare const locale: {
    lang: any;
    timePickerLocale: {
        placeholder: string;
    };
};
export default locale;
