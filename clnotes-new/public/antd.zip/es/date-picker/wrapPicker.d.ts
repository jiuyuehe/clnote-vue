export default function wrapPicker(Picker: any, defaultFormat?: string): any;
