import Table from './Table';
export default Table;
