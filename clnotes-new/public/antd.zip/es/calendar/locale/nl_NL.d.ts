import nl_NL from '../../date-picker/locale/nl_NL';
export default nl_NL;
