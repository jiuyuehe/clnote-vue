export declare const PREFIX_CLS = "ant-fullcalendar";
