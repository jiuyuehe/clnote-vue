export declare function T(): boolean;
export declare function fileToObject(file: any): any;
/**
 * 生成Progress percent: 0.1 -> 0.98
 *   - for ie
 */
export declare function genPercentAdd(): (s: any) => any;
export declare function getFileItem(file: any, fileList: any): any;
export declare function removeFileItem(file: any, fileList: any): any;
