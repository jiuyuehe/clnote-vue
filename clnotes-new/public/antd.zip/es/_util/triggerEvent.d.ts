export default function triggerEvent(el: any, type: any): void;
